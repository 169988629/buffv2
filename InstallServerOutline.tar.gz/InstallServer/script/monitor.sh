#!/bin/bash

if [ $# -eq 0 ]; then
	echo "###################"
	echo "invalid para,usage:"
	echo "-r: run project"
	echo "-k: kill project"
	echo "###################"
fi

vray_num=`ps -ef | grep v2ray | grep -v grep | wc -l`
if [ $vray_num -lt 1 -a "$1" == "-r" ]; then
	nohup /home/run_bin/v2ray -config /home/run_bin/config-vps.json 1>/dev/null 2>&1 &
	timenew=`date`
	echo "$timenew: Run /home/v2ray"
fi

if [ $vray_num -gt 0 -a "$1" == "-k" ]; then
	killall v2ray
	timenew=`date`
	echo "$timenew: Kill /home/v2ray"
fi

mini_num=`ps -ef | grep minivtun | grep -v grep | wc -l`
if [ $mini_num -lt 1 -a "$1" == "-r" ]; then
	/usr/sbin/minivtun -l 0.0.0.0:2008 -a 10.0.0.1/8 -e TQ03WN21 -E -d
	timenew=`date`
	echo "$timenew: Run /usr/sbin/minivtun"
fi

if [ $mini_num -gt 0 -a "$1" == "-k" ]; then
	killall minivtun
	timenew=`date`
	echo "$timenew: Kill /usr/sbin/minivtun"
fi
